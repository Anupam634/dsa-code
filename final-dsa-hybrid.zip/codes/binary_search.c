#include <stdio.h>

int main()
{
    int arr[20];
    int n, serarch_ele, signel = 0;
    int times_count = 0;

    printf("how many number you want to put?\n -->");
    scanf("%d", &n);
    // INPUT SECTION

    printf("Put numbers in array:\n");
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
    }
    printf("Which number you want to search?\n-->");
    scanf("%d", &serarch_ele);

    // search algo'=--0--

    int low = 0, high = n - 1;
    while (low <= high)
    {
        int mid = (low + high) / 2;
        if (arr[mid] == serarch_ele)
        {
            signel = 1;
            //    times_count = times_count+1;
            break;
        }
        else if (arr[mid] > serarch_ele)
        {
            high = mid - 1;
        }

        else
        {
            low = mid + 1;
        }
    }

    if (signel == 0)
    {
        printf("element not found, it doesn't exsit in Array");
    }
    else
    {
        printf("** element Found **");
    }

    // printf("\n --The search Element appera in array %d Times.--",times_count);

    return 0;
}