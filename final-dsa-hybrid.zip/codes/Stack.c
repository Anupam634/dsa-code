//stack in c lang
#include<stdio.h>
#define n 5;
  int top=-1;
  int stack [5];
  void push() //creating a function for push
{ int x;
  printf("\enenter the element:  ");
  scanf("%d",&x);
  if(top==5-1){
  printf("Error! Stack Overflow\n");// as the top would be already reched, there won't be any space
  }
  else{
  top ++;
  stack[top]= x; // from the beginning, as top was -1 then at first incriminat the value would be 0 and the x will be in index value 0
  }
}
 void pop() // function for pop
{ int del;
  if(top==-1){
  printf("Error! Stack under flow\n");
  }
  else{
   del= stack[top]; //as we are showing what we are deleting we are storing the value in a new 'del' variable 
   top--;
   printf ("\n The deleted item is:");
   printf("%d /n",del);
  }
}  
 void peek_top()// for peeking into the top element
{
if(top==-1){
printf("__The Stack is Empty__");
}
else{
printf("The top element is:=>");
printf("%d",stack[top]);
printf("\n");
}
}
 void display()
{ int i;
  for(i=0;i<=top;i++){ //for loop to display all current items 
  printf("%d",stack[i]);
  printf("\n");
 }
}

 void main()
{
int order;
do{
printf("Enter your choice\n\n 1 for push\n\n 2 for pop\n\n 3 to peek the top\n\n4 to display\n=>");
scanf("%d",&order);
switch(order){
case 1: push();
        break;
case 2: pop();
        break;
case 3: peek_top();
        break;
case 4: display();
        break;
}
}while(order!=0);
}


    