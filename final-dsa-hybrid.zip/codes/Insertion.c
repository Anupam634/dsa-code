#include <stdio.h>
int main()
{
    int a[20], n, i, j, rv;

    printf("\n Please Enter the total Number of Elements  :  ");
    scanf("%d", &n);

    printf("\n Please Enter the Array Elements  :  ");
    for (i = 0; i < n; i++)
        scanf("%d", &a[i]);

    for (i = 1; i <= n - 1; i++)
    {
        for (j = i; j > 0 && a[j - 1] > a[j]; j++)
        {
            rv = a[j];
            a[j] = a[j - 1];
            a[j - 1] = rv;
        }
    }
    printf("\n Insertion Sort Result : ");
    for (i = 0; i < n; i++)
    {
        printf(" %d \t", a[i]);
    }
    printf("\n");
    return 0;
}