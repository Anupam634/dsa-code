#include <stdio.h>
#include <stdlib.h>
struct linklist
{
    int data;
    struct linklist *next;
};
struct linklist *h = NULL, *q;

void insertionAtLAst()
{
    struct linklist *p = (struct linklist *)malloc(sizeof(struct linklist));
    q = h;
    printf("Please enter the Data Of New Node: ");
    scanf("%d", &p->data);
    p->next = NULL;
    if (h == NULL)
    {
        h = p;
    }
    else
    {
        while (q->next != NULL)
        {
            q = q->next;
        }
        q->next = p;
    }
    printf("------- ------- Succesfully insert ---------  --------- \n");
}

void insertionAtFirst()
{
    struct linklist *p = (struct linklist *)malloc(sizeof(struct linklist));
    printf("Please enter the Data Of New Node: ");
    scanf("%d", &p->data);
    p->next = h;
    h = p;
    printf("------- ------- Succesfully insert ---------  --------- \n");
}

void insertionAfterANode()
{
    int mc = 0, s;
    printf("Enter the Data Of node Where You want to Add :");
    scanf("%d", &s);
    q = h;
    while (q != NULL)
    {
        if (s == q->data)
        {
            mc = 1;
            break;
        }
        q = q->next;
    }
    if (mc == 1)
    {
        struct linklist *p = (struct linklist *)malloc(sizeof(struct linklist));
        printf("Please enter the Data Of New Node: ");
        scanf("%d", &p->data);
        p->next = q->next;
        q->next = p;

    }
    else
    {
       printf("Expected Node not founded!!!");
    }
}

/*
For this Opertion have many Option
1. after insert after the node can Swap between those number....
2. if p->next->data == s......

*/
void insertionBeforeANode()
{
    int mc = 0, s;
    printf("Enter the Data Of node Where You want to Add :");
    scanf("%d", &s);
    q = h;
    struct linklist *t = h;
    while (q != NULL)
    {
        if (s == q->data)
        {
            mc = 1;
            break;
        }
        t=q;
        q = q->next;
    }
    if (mc == 1)
    {
        struct linklist *p = (struct linklist *)malloc(sizeof(struct linklist));
        printf("Please enter the Data Of New Node: ");
        scanf("%d", &p->data);
        p->next = q;
        t->next = p;

    }
    else
    {
       printf("Expected Node not founded!!!");
    }
}

void deleteANode()
{
    int mc = 0, s;
    printf("Enter the Data Of node That You want next  delete:");
    scanf("%d", &s);
    q = h;
    struct linklist *t = h;
    while (q != NULL)
    {
        if (s == q->data)
        {
            mc = 1;
            break;
        }
        t=q;
        q = q->next;
    }
    if (mc == 1)
    {
        t->next = q->next;
        free(q);
    }
    else
    {
       printf("Expected Node not founded!!!");
    }
}

void deletationInFirst()
{
    q = h;
    if (h == NULL)
    {
        printf("Nothing Have");
    }
    else
    {
        h = h->next;
        printf("the Deleted element is: %d\n THE DELTATOIN AT FIRST SUCCESFULL!!!!", q->data);
        free(q);
    }
}

void traversal()
{
    printf("\n \\--> ");
    q = h;
    if (q == NULL)
    {
        printf("The Linklist Haven't Create\n");
    }
    else
    {
        while (q != NULL)
        {
            printf("%d ", q->data);
            q = q->next;
        }
        printf("\n");
    }
}

void sorting(){
    struct linklist*i;
    for (i = h; i != NULL; i= i->next)
    {
        int m = i->data;
        struct linklist* m_i = i;
        for (struct linklist* j = i->next; j!= NULL; j= j->next)
        {
            if (m>j->data)
            {
                m=j->data;
                m_i = j;
            }
            
        }

        int temp = m_i->data;
        m_i->data = i->data;
        i->data =temp;
        
    }
    
}

int main()
{
    h = (struct linklist *)malloc(sizeof(struct linklist));
    struct linklist *node1 = (struct linklist *)malloc(sizeof(struct linklist));
    struct linklist *node2 = (struct linklist *)malloc(sizeof(struct linklist));
    struct linklist *node3 = (struct linklist *)malloc(sizeof(struct linklist));

    h->data =21;
    h->next =node1;

    node1->data =22;
    node1->next = node2;

    node2->data= 23;
    node2->next = node3;

    node3->data = 24;
    node3->next = NULL;

    while (96)
    {
        printf("\nPress 1 : For Traversal In Linklist\n press 2: For Insertion a New Node At last position\n press 3:For Insertion a New Node At First position\n press 4:For Deleted the First Node \n press 5:For Insert a Node After Any Node \n press 6:For Insert a Node Before  Any Node\n  press 6:For delete Any Node\n press 7: Exit \n");
        int n;
        printf("Enter Your Choise : ");
        scanf("%d", &n);
        switch (n)
        {
        case 1:
            traversal();
            break;
        case 2:
            insertionAtLAst();
            break;
        case 3:
            insertionAtFirst();
            break;
        case 4:
            deletationInFirst();
            break;
        case 5:
            insertionAfterANode();
            break;
        case 6:
           insertionBeforeANode();
            break;
        case 7:
           deleteANode();
            break;
        case 8:
            exit(0);
            break;

        default:
            printf("choose Again");
            break;
        }
    }

    return 0;
}