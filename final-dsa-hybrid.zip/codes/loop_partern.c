#include <stdio.h>

int main()
{
    // 1st pattern:
    // 1
    // 21
    // 321
    // 4321
    // 54321
    // 654321

    printf("1st pattern\n");
    for (int a = 1; a <= 6; a++)
    {
        for (int i = a; i >= 1; i--)
        {
            printf("%d", i);
        }
        printf("\n");
    }
    printf("\n\n");
    // 2nd pattern--------------------------------------------
    // 12345
    // 1234
    // 1233
    // 12
    // 1
    printf("2nd pattern\n");
    for (int a = 5; a >= 1; a--)
    {
        for (int i = 1; i <= a; i++)
        {
            printf("%d", i);
        }
        printf("\n");
    }

    printf("\n\n");

    //  3RD PATTERN-------------------------------------------
    printf("3RD PATTERN\n");
    for (int a = 6; a >= 1; a--)
    {
        for (int i = 1; i <= a - 1; i++)
        {
            printf(" ");
        }
        for (int j = 1; j <= 6 - (a - 1); j++)
        {
            printf("%d", j);
        }
        printf("\n");
    }

    // 4th PATTERN -----------------------------
    printf("4th PATTERN\n");
    for (int a = 5; a >= 1; a--)
    {
        for (int i = 1; i <= a - 1; i++)
        {
            printf(" ");
        }
        for (int j = 5; j >= a; j--)
        {
            printf("%d", j);
        }
        printf("\n");
    }
    // 5th pattern-----------------------------
    printf("5th PATTERN\n");
    for (int a = 5; a >= 1; a--)
    {
        for (int j = a; j <= 4; j++)
        {
            printf(" ");
        }
        for (int i = 1; i <= a; i++)
        {
            printf("%d", i);
        }

        printf("\n");
    }
    //    6th PATTERN -------------------------------
    printf("6th PATTERN\n");
    for (int i = 5; i >= 1; i--)
    {
        for (int a = (5 - i); a > 0; a--)
        {
            printf(" ");
        }
        for (int j = i; j >= 1; j--)
        {
            printf("%d", j);
        }
        printf("\n");
    }

    //  7th Pattern
    printf("7th PATTERN\n");
    for (int i = 1; i <= 5; i++)
    {
        if (i % 2 == 0)
        {
            for (int j = i; j >= 1; j--)
            {
                printf("%d", j);
            }
        }
        else
        {
            for (int a = 1; a <= i; a++)
            {
                printf("%d", a);
            }
        }
        printf("\n");
    }
    // 8th pattern
    printf("\n8th Pattern\n");
    for (int i = 0; i < 5; i++)
    {
        for (int a = 1; a <= i; a++)
        {
            printf(" ");
        }
        for (int j = 5; j > i; j--)
        {
            printf("%d", j);
        }
        printf("\n");
    }

    // 9th PATTERN
    printf("\n9th PATTERN\n");
    int c = -1;
    for (int k = 5; k >= 1; k--)
    {
        for (int i = 1; i <= k; i++)
        {
            printf("*");
        }
        for (int j = 1; j <= c; j++)
        {
            printf(" ");
        }
        if (k == 5)
        {
            for (int i = 1; i <= 4; i++)
            {
                printf("*");
            }
        }
        else
        {
            for (int i = 1; i <= k; i++)
            {
                printf("*");
            }
        }
        c = c + 2;
        printf("\n");
    }

    // 10th PATTERN
    printf("\n10th PATTERN\n");
    int K = 4;
    for (int i = 1; i <= 9; i += 2)
    {
        for (int a = 1; a <= K; a++)//--------> Sapce
        {
            printf(" ");
        }
        for (int j = 1; j <= i; j++) //---------> for Integer
        {
            printf("%d", j);
        }
        K = K - 1;

        printf("\n");
    }

    return 0;
}