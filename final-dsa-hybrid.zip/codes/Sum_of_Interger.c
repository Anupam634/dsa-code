#include<stdio.h>

int main(){
    long long int s=1111111111100000;
    int sum =0,r;
    do
    {
       r=s%10;
       sum=sum + r;
       s= s/10;
    } while (s!=0);
    printf("%d",sum);
    return 0;
}