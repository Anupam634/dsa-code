#include<stdio.h>
  int main(){
//  	PATTERN 1-------------------
printf("PArten no : 1\n");
 	for(int i=0; i<5;i++){
 		for(int a=1;a<=i;a++){
 			printf(" ");
		  }
 		for(int j=5;j>i;j--){
 			printf("%d",j);
		  }	
		  printf("\n");
	  } 

//PATTERN 2------------------
printf("PArten no :2 \n");
int l=4;
	for(int i=1;i<=9; i= i+2){
	for(int a=1; a<=l;a++){
		printf(" ");
	}
	for(int j =1;j<=i; j++){
		printf("%d",j);
	}
		l=l-1;
		printf("\n");
	}

// PATTERN 3----------------------
	
	printf
("PArten no :3 \n");
	int c=-1;
	for(int k= 5; k>=1; k--){
		for(int i =1;i<=k;i++){
			printf("*");
		}
		for(int j=1; j<=c; j++){
			printf(" ");
		}
		if(k==5){
		for(int i =1;i<=4;i++){
			printf("*");
		}
		}
		else{
			for(int i =1;i<=k;i++){
			printf("*");
		}
		}
		c =c+2;
		printf("\n");
	}
	  return 0;
  }
