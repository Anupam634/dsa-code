#include <stdio.h>
struct stack
{
  int a[10];
  int top;
} s;

void Printsarray()
{
    for (int i = 0; i < s.top; i++)
    {
        printf(" %d ", s.a[i]);
    }
}

void Insertion(int value)
{

    if (s.top == 11)
    {
        printf("Stack Overflow!");
    }
    else
    {
        s.a[s.top] = value;
        s.top++;
    }
}

int deletation()
{
    s.top--;
    int val = s.a[s.top];
    return val;
}
int main()
{
    // struct stack s;s.
    s.top = 0;
    Insertion(5);
    Insertion(15);
    Insertion(25);
    Insertion(35);
    Printsarray();
    printf("\nDeleted value is :%d\n-->", deletation());
    Printsarray();
    return 0;
}