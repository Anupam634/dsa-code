#include <stdio.h>

int main()
{
    int a[25], i, j, n, k, rv;
    printf("enter the size of the array:-"); // taking the size of the array
    scanf("%d", &n);
    printf("The elements are:-"); // taking the elemnts of the array
    for (i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n - 1; i++) // outer loop (itteration)
    {
        for (j = i + 1; j < n; j++) // inner loop (swaping)
        {
            if (a[j] > a[j + 1])
            {
                rv = a[j];

                a[j] = a[j + 1];
                a[j + 1] = rv;
            }
        }
    }
    printf("selection sorted alignment:-> ");
    for (k = 0; k < n; k++)
    {
        printf("%d\t", a[k]);
    }
    return 0;
}