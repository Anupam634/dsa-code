// SIMPLE BINARY SEARCH PROGRAM IT ONLY WORKS ON SORTED ARRAY 

// the array should have to be sorted

#include <stdio.h>

int main(){

    int i, low, high, mid, numberOfElements, searchElement, elementArray[100];

    // @@@@ taking the number of element in the array @@@@
    printf("Enter number of elements :\n");
    scanf("%d",&numberOfElements);

    // @@@@ taking the elements @@@@
    printf("Enter %d elements :\n", numberOfElements);
    for(i = 0; i < numberOfElements; i++){
        scanf("%d",&elementArray[i]);
    }

    // @@@@ taking the element that we want to find @@@@
    printf("Enter value to find :\n");
    scanf("%d", &searchElement);


    low = 0;
    high = numberOfElements - 1;
    mid = (low+high)/2;

    while (low <= high) {
        if(elementArray[mid] < searchElement)
        low = mid + 1;
        else if (elementArray[mid] == searchElement) {
            printf("%d found at location %d \n", searchElement, mid+1);
            break;
        }
        else
        high = mid - 1;
        mid = (low + high)/2;
    }
    if(low > high)
    printf("Not found! %d isn't present in the list.\n", searchElement);
    return 0;
}