#include<stdio.h>
int gcd(int dvdn, int divisr){
    int remainder = dvdn%divisr;
    if (remainder==0)
    {
        return divisr;
    }
    gcd(divisr,remainder);
    
} 
void series(int upper, int lower,int n){
    
    if (n!=0)
    {
     int up = upper+3;
    int dwn = lower *2;
    printf(" %d/%d ",up,dwn);
    n--;
    series(up,dwn,n);
    }

    
}
int main(){
    printf("the GCD of 90 and 35 is : %d ",gcd(90,35));
    // series(2,3,4);
    return 0;
}