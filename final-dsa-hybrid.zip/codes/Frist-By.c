//=================  THE CLASS OF PP AND DATE 04/08/22

	#include<stdio.h>
int main(){
//	int a,b,f;
//    int r = printf("hello0 %d",a);
//    printf("\n r = %d\n", r);
//  

//int scan_return = scanf("%d %d 5d", &a,&b);
//printf("scan_return = %d",scan_return);
//---------------------------------------------------------------------------------
// after writing nmbber at right gap then it will succesfully Acsep the number
//    int s = scanf("ram %d", &a);
//    printf("%d",s);
//--------------------------------------------------------------------  
//  	scanf("%d-%d-%d", &a,&b,&f);
//    printf("%d/%d/%d",a,b,f);
//   OUT-PUT: 04-
//   			08-
//			2022
//			4/8/2022
//----------------------------------------------------------------
//printf("%%d\n");
//printf("\\nmp");
//printf("\a");
// Compilar have ready \n \t meaning 
// (\)---> Excape scquence.
// That's why (\) change the meanig of normal n or t....... (\) work is changing the action or meaning of next char
// that's how it also change the meaning of \ ,...........,if we use (\) before another (\)..
// \a ---> meanig alarm
// Also when add (\) before the  s or n it act like one charecter insteed if two char

//-----------------------------------------------------------------------------------
//printf("\rabc\bxyz");
// (\b) if it put middle of a word then it will dellete the previos words

//printf("rahul says\"i will go\"");
//--------------------------------------------------------------------------------

// "if" is a control statement
// "OS" check the condition and return 1/0 and then it send in if ......... After that if it  1 or an y non-zero then exicute the 'if' statement
//if it return 0 thn exicute 'else'

//if(printf("Ab") == 1){
//	printf("ab");
//}
//else{
//	printf("C");
//}

// in if Write ANY false statement with printf then it will print both in () and else statement.
//---------------------------------------------------------------
//  OS CHECKING IT TRUE OR FALSE  
// int a = -5;
// int r =a== -5;
// printf("\n After checking by OS return r= %d", r);

//----------------------------------------------------------------- 
 
 // FOR(1_part; 2_part; 3_part)
// 1_part ---> run or exicute one time and before the loop(strat)....
// 3_part ---> it for incriment and decriment BUT its not MENDETORY.... u can wirte it at the end of the loop
// 2_part ---> check the condition return non-zero or zero(0)....
//int a;
//for(scanf("%d",&a);a; ){
//	printf("%d",a--);
//}
int a;
//for(a =10;printf("%d",a);){
//	a--;
//}-----------------> INFINITE LOOP

//for(a =5;printf("%d",a)<2;){
//	a--;
//} ---------> UNTIL -1 ,because after print 'printf' return valu or number of char

 
 
 
    return 0;
}
