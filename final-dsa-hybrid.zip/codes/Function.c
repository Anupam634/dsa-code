#include<stdio.h>

// void hello(char name[]){
//     printf("Hi Fucker %s",name);
// }

int Sum(int a,int b){
    int c = a+b;
    return c;
}
int main(){

//     char Name[10];
//     gets(Name);
//  hello(Name) ;    
 printf("\nThe Sum Of 2 And 5 is : %d",Sum(2,5));
    return 0;
}