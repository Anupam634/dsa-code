#include <stdio.h>
int fibonachi(int n)
{
    if (n == 0 || n == 1)
    {
        return n;
    }
    else
    {
        return fibonachi(n - 1) + fibonachi(n - 2);
    }
}

void disp(int n){
    printf("%d ",n);    //-------> If Print put Previous of Recurtion Then It Will gone to forward manner
    if (n<5)
    {
        disp(n+1);
    }
     printf("%d ",n);  //_----------> If write after the recurtion then it will gone backward manner;;;;
}
int main()
{
    // int n =7;
    // printf("\nenter the position of that series :--> ");
    // scanf("%d", &n);

    // printf("\nFibonacchi Of %d th series is : %d",n, fibonachi(n));
    disp(1);
    return 0;
}